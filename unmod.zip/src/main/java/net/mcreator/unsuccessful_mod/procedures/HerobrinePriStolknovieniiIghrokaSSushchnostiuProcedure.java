package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.entity.Entity;

public class HerobrinePriStolknovieniiIghrokaSSushchnostiuProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!entity.level().isClientSide())
			entity.discard();
	}
}