package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

public class CobblestoneSplinterPriObnovlieniiTikaSushchnostiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level)
			_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
					"execute as @e[ type= unsuccessful_mod:cobblestone_splinter] at @a[distance=..24] facing entity @s eyes positioned ^ ^ ^1 if block ~ ~ ~ minecraft:air rotated as @a[limit=1] positioned ^ ^ ^-1 if entity @a[distance=..1] run effect give @s minecraft:slowness 1 255 true");
		if ((world.getBlockState(BlockPos.containing(x, y - 1, z))) == Blocks.WATER.defaultBlockState()) {
			world.setBlock(BlockPos.containing(x, y - 1, z), Blocks.COBBLESTONE.defaultBlockState(), 3);
		}
	}
}