package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;

public class SpawnWaterOrLavaPriNachalnomPrizyvieSushchnostiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (Math.random() > 0.5) {
			world.setBlock(BlockPos.containing(x + Mth.nextInt(RandomSource.create(), 1, 10), y + Mth.nextInt(RandomSource.create(), 10, 75), z + Mth.nextInt(RandomSource.create(), 1, 10)), Blocks.WATER.defaultBlockState(), 3);
			if (!entity.level().isClientSide())
				entity.discard();
		} else {
			world.setBlock(BlockPos.containing(x + Mth.nextInt(RandomSource.create(), 1, 10), y + Mth.nextInt(RandomSource.create(), 10, 75), z + Mth.nextInt(RandomSource.create(), 1, 10)), Blocks.LAVA.defaultBlockState(), 3);
			if (!entity.level().isClientSide())
				entity.discard();
		}
	}
}