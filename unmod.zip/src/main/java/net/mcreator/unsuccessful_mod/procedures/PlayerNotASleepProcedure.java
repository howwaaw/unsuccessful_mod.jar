package net.mcreator.unsuccessful_mod.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerWakeUpEvent;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.unsuccessful_mod.network.UnsuccessfulModModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class PlayerNotASleepProcedure {
	@SubscribeEvent
	public static void onEntityEndSleep(PlayerWakeUpEvent event) {
		execute(event, event.getEntity().level());
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		UnsuccessfulModModVariables.MapVariables.get(world).playersleep = false;
		UnsuccessfulModModVariables.MapVariables.get(world).markSyncDirty();
	}
}