package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.unsuccessful_mod.init.UnsuccessfulModModBlocks;

public class SpawnNotFoundBlocksPriObnovlieniiTikaSushchnostiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		world.setBlock(BlockPos.containing(x, y - 2, z), UnsuccessfulModModBlocks.NOT_FOUND.get().defaultBlockState(), 3);
	}
}