package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.unsuccessful_mod.network.UnsuccessfulModModVariables;
import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

public class StrangePlayer1PriStolknovieniiIghrokaSSushchnostiuProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (!entity.level().isClientSide())
			entity.discard();
		sourceentity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.GENERIC)), 4);
		UnsuccessfulModModVariables.MapVariables.get(world).screamer = true;
		UnsuccessfulModModVariables.MapVariables.get(world).markSyncDirty();
		if (world instanceof ServerLevel _level)
			_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
					"playsound unsuccessful_mod:screamer master @a 0 10000 0 10000 1 1");
		UnsuccessfulModMod.queueServerWork(40, () -> {
			UnsuccessfulModModVariables.MapVariables.get(world).screamer = false;
			UnsuccessfulModModVariables.MapVariables.get(world).markSyncDirty();
		});
	}
}