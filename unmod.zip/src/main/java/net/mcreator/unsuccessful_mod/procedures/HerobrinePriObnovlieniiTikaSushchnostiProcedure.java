package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.unsuccessful_mod.init.UnsuccessfulModModMobEffects;
import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

public class HerobrinePriObnovlieniiTikaSushchnostiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (world instanceof ServerLevel _level)
			_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
					"execute as @e[type= unsuccessful_mod:herobrine] at @a[distance=..63] facing entity @s eyes positioned ^ ^ ^1 if block ~ ~ ~ minecraft:air rotated as @a[limit=1] positioned ^ ^ ^-1 if entity @a[distance=..1] run effect give @s unsuccessful_mod:despawn 1 255 true");
		if (entity instanceof LivingEntity _livEnt1 && _livEnt1.hasEffect(UnsuccessfulModModMobEffects.DESPAWN.get())) {
			UnsuccessfulModMod.queueServerWork(5, () -> {
				if (!entity.level().isClientSide())
					entity.discard();
				if (Math.random() > 0.5) {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"playsound minecraft:ambient.cave master @a 0 10000 0 10000 1 1");
				}
			});
		}
	}
}