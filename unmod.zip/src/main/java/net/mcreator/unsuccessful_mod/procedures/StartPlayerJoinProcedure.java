package net.mcreator.unsuccessful_mod.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.unsuccessful_mod.network.UnsuccessfulModModVariables;
import net.mcreator.unsuccessful_mod.init.UnsuccessfulModModEntities;
import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class StartPlayerJoinProcedure {
	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ());
	}

	public static void execute(LevelAccessor world, double x, double y, double z) {
		execute(null, world, x, y, z);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
		if (UnsuccessfulModModVariables.MapVariables.get(world).startplayer == false) {
			UnsuccessfulModMod.queueServerWork(300, () -> {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = UnsuccessfulModModEntities.START_PLAYER.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(1);
						entityToSpawn.setYBodyRot(1);
						entityToSpawn.setYHeadRot(1);
					}
				}
				UnsuccessfulModModVariables.MapVariables.get(world).startplayer = true;
				UnsuccessfulModModVariables.MapVariables.get(world).markSyncDirty();
			});
		}
	}
}