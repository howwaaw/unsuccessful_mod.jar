package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.unsuccessful_mod.network.UnsuccessfulModModVariables;

public class ReturnVhsProcedure {
	public static void execute(LevelAccessor world) {
		UnsuccessfulModModVariables.MapVariables.get(world).vhsoverlay = true;
		UnsuccessfulModModVariables.MapVariables.get(world).markSyncDirty();
	}
}