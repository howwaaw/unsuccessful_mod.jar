package net.mcreator.unsuccessful_mod.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

import net.minecraft.world.entity.vehicle.MinecartChest;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.CaveSpider;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class EntityNameProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Villager || entity instanceof Salmon || entity instanceof Bee || entity instanceof Cat || entity instanceof Wolf || entity instanceof Chicken || entity instanceof Creeper || entity instanceof Skeleton
				|| entity instanceof Zombie || entity instanceof Horse || entity instanceof CaveSpider || entity instanceof Spider || entity instanceof Sheep || entity instanceof Cow || entity instanceof Pig || entity instanceof Squid
				|| entity instanceof MinecartChest || entity instanceof Boat) {
			if (Math.random() >= 0.5) {
				entity.setCustomName(Component.literal("Sacrifice"));
				if (Math.random() >= 0.4) {
					entity.setCustomName(Component.literal("\u00A74I see you"));
					if (Math.random() >= 0.4) {
						entity.setCustomName(Component.literal("0100100001100101011011000110110001101111"));
						if (Math.random() >= 0.4) {
							entity.setCustomName(Component.literal("\u00A7kErrorEntity"));
							if (Math.random() >= 0.3) {
								entity.setCustomName(Component.literal("Testificate"));
								if (Math.random() >= 0.3) {
									entity.setCustomName(Component.literal("Behind you"));
									if (Math.random() >= 0.3) {
										entity.setCustomName(Component.literal("He's near"));
										if (Math.random() >= 0.2) {
											entity.setCustomName(Component.literal("Lava or Chicken?"));
											if (Math.random() >= 0.2) {
												entity.setCustomName(Component.literal("It's you"));
												if (Math.random() >= 0.2) {
													entity.setCustomName(Component.literal("err.type=scary"));
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}