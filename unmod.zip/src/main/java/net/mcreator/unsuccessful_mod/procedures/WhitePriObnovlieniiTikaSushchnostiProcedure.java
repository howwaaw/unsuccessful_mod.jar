package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

public class WhitePriObnovlieniiTikaSushchnostiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		UnsuccessfulModMod.queueServerWork(5, () -> {
			if (!entity.onGround()) {
				if (!entity.level().isClientSide())
					entity.discard();
				if (Math.random() > 0.5) {
					SpawnDoorTeleportProcedure.execute(world, x, y, z);
				}
			}
		});
	}
}