package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.unsuccessful_mod.network.UnsuccessfulModModVariables;

public class HeIsHereUsloviiePokazaNalozhieniiaProcedure {
	public static boolean execute(LevelAccessor world) {
		if (UnsuccessfulModModVariables.MapVariables.get(world).heishere == true) {
			return true;
		}
		return false;
	}
}