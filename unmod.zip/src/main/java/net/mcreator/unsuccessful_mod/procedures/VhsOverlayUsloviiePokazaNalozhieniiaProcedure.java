package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.unsuccessful_mod.network.UnsuccessfulModModVariables;

public class VhsOverlayUsloviiePokazaNalozhieniiaProcedure {
	public static boolean execute(LevelAccessor world) {
		if (UnsuccessfulModModVariables.MapVariables.get(world).vhsoverlay == true) {
			return true;
		}
		return false;
	}
}