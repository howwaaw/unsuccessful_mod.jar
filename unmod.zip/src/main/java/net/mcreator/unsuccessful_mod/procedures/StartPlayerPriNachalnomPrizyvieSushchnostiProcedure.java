package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;

import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

public class StartPlayerPriNachalnomPrizyvieSushchnostiProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (world instanceof ServerLevel _level) {
			_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal(("\u00A7e" + Component.translatable("msg.startplayerjoinedthegame").getString())), false);
		}
		UnsuccessfulModMod.queueServerWork(60, () -> {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("<dddb6e4c-2d5d-44a5-8af3-83ea055cb28a> Hello"), false);
			}
			UnsuccessfulModMod.queueServerWork(80, () -> {
				if (world instanceof ServerLevel _level) {
					_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("<dddb6e4c-2d5d-44a5-8af3-83ea055cb28a> I want to tell you what's here..."), false);
				}
				UnsuccessfulModMod.queueServerWork(60, () -> {
					if (world instanceof ServerLevel _level) {
						_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("<dddb6e4c-2d5d-44a5-8af3-83ea055cb28a> Oh, I forgot"), false);
					}
					UnsuccessfulModMod.queueServerWork(100, () -> {
						if (world instanceof ServerLevel _level) {
							_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("<dddb6e4c-2d5d-44a5-8af3-83ea055cb28a> Okay, it's (probably) not that important, good luck!"), false);
						}
						UnsuccessfulModMod.queueServerWork(60, () -> {
							if (!entity.level().isClientSide())
								entity.discard();
							if (world instanceof ServerLevel _level) {
								_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal(("\u00A7e" + Component.translatable("msg.startplayerleftthegame").getString())), false);
							}
						});
					});
				});
			});
		});
	}
}