package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class EntityNotFoundPriNachalnomPrizyvieSushchnostiProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setCustomName(Component.literal("\u00A7kPlayer001"));
	}
}