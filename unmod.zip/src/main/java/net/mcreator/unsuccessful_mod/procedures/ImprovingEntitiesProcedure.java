package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class ImprovingEntitiesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(BlockPos.containing(x, y - 1, z))) == Blocks.WATER.defaultBlockState()) {
			world.setBlock(BlockPos.containing(x, y - 1, z), Blocks.COBBLESTONE.defaultBlockState(), 3);
		}
	}
}