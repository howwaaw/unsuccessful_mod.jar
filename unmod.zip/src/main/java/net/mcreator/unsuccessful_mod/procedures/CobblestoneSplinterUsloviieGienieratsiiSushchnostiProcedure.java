package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.unsuccessful_mod.init.UnsuccessfulModModEntities;

public class CobblestoneSplinterUsloviieGienieratsiiSushchnostiProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		if (y <= 15 && y >= -45) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = UnsuccessfulModModEntities.COBBLESTONE_SPLINTER.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				}
			}
			return true;
		}
		return false;
	}
}