package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.unsuccessful_mod.network.UnsuccessfulModModVariables;

public class ScreamerUsloviiePokazaNalozhieniiaProcedure {
	public static boolean execute(LevelAccessor world) {
		if (UnsuccessfulModModVariables.MapVariables.get(world).screamer == true) {
			return true;
		}
		return false;
	}
}