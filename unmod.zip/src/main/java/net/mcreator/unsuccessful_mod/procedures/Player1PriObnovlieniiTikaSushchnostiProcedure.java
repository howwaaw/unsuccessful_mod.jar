package net.mcreator.unsuccessful_mod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

public class Player1PriObnovlieniiTikaSushchnostiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		UnsuccessfulModMod.queueServerWork(5, () -> {
			if (!entity.onGround()) {
				if (!entity.level().isClientSide())
					entity.discard();
				if (Math.random() > 0.7) {
					SpawnStrangePlayer1Procedure.execute(world, x, y, z);
				}
			}
		});
	}
}