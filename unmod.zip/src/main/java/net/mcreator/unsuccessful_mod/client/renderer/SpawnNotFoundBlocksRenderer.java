package net.mcreator.unsuccessful_mod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.unsuccessful_mod.entity.SpawnNotFoundBlocksEntity;

public class SpawnNotFoundBlocksRenderer extends HumanoidMobRenderer<SpawnNotFoundBlocksEntity, HumanoidModel<SpawnNotFoundBlocksEntity>> {
	private final ResourceLocation entityTexture = new ResourceLocation("unsuccessful_mod:textures/entities/skin-z0uq.png");

	public SpawnNotFoundBlocksRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<SpawnNotFoundBlocksEntity>(context.bakeLayer(ModelLayers.PLAYER)), 0f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(SpawnNotFoundBlocksEntity entity) {
		return entityTexture;
	}
}