package net.mcreator.unsuccessful_mod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.unsuccessful_mod.entity.EntityEntityEntity2Entity;

public class EntityEntityEntity2Renderer extends HumanoidMobRenderer<EntityEntityEntity2Entity, HumanoidModel<EntityEntityEntity2Entity>> {
	private final ResourceLocation entityTexture = new ResourceLocation("unsuccessful_mod:textures/entities/skin-z0uq.png");

	public EntityEntityEntity2Renderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<EntityEntityEntity2Entity>(context.bakeLayer(ModelLayers.PLAYER)), 0f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(EntityEntityEntity2Entity entity) {
		return entityTexture;
	}
}