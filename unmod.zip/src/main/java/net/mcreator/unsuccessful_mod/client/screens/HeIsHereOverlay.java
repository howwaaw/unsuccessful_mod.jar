package net.mcreator.unsuccessful_mod.client.screens;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;

import net.mcreator.unsuccessful_mod.procedures.HeIsHereUsloviiePokazaNalozhieniiaProcedure;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class HeIsHereOverlay {
	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		if (HeIsHereUsloviiePokazaNalozhieniiaProcedure.execute(world)) {
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.unsuccessful_mod.he_is_here.label_he_is_here"), w / 2 + -27, h / 2 + 59, -65485, false);
		}
	}
}