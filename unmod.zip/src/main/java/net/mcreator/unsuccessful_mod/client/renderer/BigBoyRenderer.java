package net.mcreator.unsuccessful_mod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.unsuccessful_mod.entity.BigBoyEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class BigBoyRenderer extends HumanoidMobRenderer<BigBoyEntity, HumanoidModel<BigBoyEntity>> {
	private final ResourceLocation entityTexture = new ResourceLocation("unsuccessful_mod:textures/entities/skin-9dkf.png");

	public BigBoyRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<BigBoyEntity>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	protected void scale(BigBoyEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(12f, 12f, 12f);
	}

	@Override
	public ResourceLocation getTextureLocation(BigBoyEntity entity) {
		return entityTexture;
	}
}