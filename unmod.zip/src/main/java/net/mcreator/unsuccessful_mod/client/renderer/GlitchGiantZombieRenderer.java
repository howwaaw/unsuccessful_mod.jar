package net.mcreator.unsuccessful_mod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.unsuccessful_mod.entity.GlitchGiantZombieEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class GlitchGiantZombieRenderer extends HumanoidMobRenderer<GlitchGiantZombieEntity, HumanoidModel<GlitchGiantZombieEntity>> {
	private final ResourceLocation entityTexture = new ResourceLocation("unsuccessful_mod:textures/entities/skin-z8zn.png");

	public GlitchGiantZombieRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<GlitchGiantZombieEntity>(context.bakeLayer(ModelLayers.PLAYER)), 3f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	protected void scale(GlitchGiantZombieEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(21f, 21f, 21f);
	}

	@Override
	public ResourceLocation getTextureLocation(GlitchGiantZombieEntity entity) {
		return entityTexture;
	}
}