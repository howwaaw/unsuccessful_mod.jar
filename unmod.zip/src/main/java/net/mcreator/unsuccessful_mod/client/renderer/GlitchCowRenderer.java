package net.mcreator.unsuccessful_mod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.CowModel;

import net.mcreator.unsuccessful_mod.entity.GlitchCowEntity;

public class GlitchCowRenderer extends MobRenderer<GlitchCowEntity, CowModel<GlitchCowEntity>> {
	private final ResourceLocation entityTexture = new ResourceLocation("unsuccessful_mod:textures/entities/cow-glitch-on-planetminecraft-com.png");

	public GlitchCowRenderer(EntityRendererProvider.Context context) {
		super(context, new CowModel<GlitchCowEntity>(context.bakeLayer(ModelLayers.COW)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(GlitchCowEntity entity) {
		return entityTexture;
	}

	@Override
	protected boolean isShaking(GlitchCowEntity entity) {
		return true;
	}
}