package net.mcreator.unsuccessful_mod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.unsuccessful_mod.entity.PigHumanEntity;

public class PigHumanRenderer extends HumanoidMobRenderer<PigHumanEntity, HumanoidModel<PigHumanEntity>> {
	private final ResourceLocation entityTexture = new ResourceLocation("unsuccessful_mod:textures/entities/760be5e96123f943.png");

	public PigHumanRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<PigHumanEntity>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(PigHumanEntity entity) {
		return entityTexture;
	}
}