/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.unsuccessful_mod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class UnsuccessfulModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, UnsuccessfulModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(UnsuccessfulModModBlocks.NOT_FOUND.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(UnsuccessfulModModItems.SPAWN_NOT_FOUND_BLOCKS_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.HEROBRINE_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.ENTITY_NOT_FOUND_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.INVISIBLE_STEP_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.COBBLESTONE_SPLINTER_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.GLITCH_COW_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.PIG_HUMAN_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.GLITCH_ZOMBIE_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.GLITCH_GIANT_ZOMBIE_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.CAVE_PLAYER_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.BIG_BOY_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.HCTON_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.START_PLAYER_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.ENTITY_ENTITY_ENTITY_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.ENTITY_HE_IS_HERE_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.WHITE_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.STRANGE_PLAYER_1_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.PLAYER_1_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.SPAWN_WATER_OR_LAVA_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.TIME_CHANGE_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.ENTITY_ENTITY_ENTITY_2_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.GLITCH_STEVE_SPAWN_EGG.get());
			tabData.accept(UnsuccessfulModModItems.ENTITY_SPAWN_KILL_ANIMAL_SPAWN_EGG.get());
		}
	}
}