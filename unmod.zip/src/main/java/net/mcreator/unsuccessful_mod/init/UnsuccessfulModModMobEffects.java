/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.unsuccessful_mod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.unsuccessful_mod.potion.DespawnMobEffect;
import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

public class UnsuccessfulModModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, UnsuccessfulModMod.MODID);
	public static final RegistryObject<MobEffect> DESPAWN = REGISTRY.register("despawn", DespawnMobEffect::new);
}