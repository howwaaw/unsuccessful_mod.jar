/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.unsuccessful_mod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

public class UnsuccessfulModModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, UnsuccessfulModMod.MODID);
	public static final RegistryObject<SoundEvent> STRANGEMUSIC = REGISTRY.register("strangemusic", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "strangemusic")));
	public static final RegistryObject<SoundEvent> HEISNEAR = REGISTRY.register("heisnear", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "heisnear")));
	public static final RegistryObject<SoundEvent> PHONESIGNALIS = REGISTRY.register("phonesignalis", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "phonesignalis")));
	public static final RegistryObject<SoundEvent> CRUNCH = REGISTRY.register("crunch", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "crunch")));
	public static final RegistryObject<SoundEvent> DISCORD = REGISTRY.register("discord", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "discord")));
	public static final RegistryObject<SoundEvent> THEHORROR = REGISTRY.register("thehorror", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "thehorror")));
	public static final RegistryObject<SoundEvent> HEISHERE = REGISTRY.register("heishere", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "heishere")));
	public static final RegistryObject<SoundEvent> STRANGESOUND = REGISTRY.register("strangesound", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "strangesound")));
	public static final RegistryObject<SoundEvent> WINDOWS10ERROR = REGISTRY.register("windows10error", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "windows10error")));
	public static final RegistryObject<SoundEvent> SCREAMER = REGISTRY.register("screamer", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "screamer")));
	public static final RegistryObject<SoundEvent> SPAWNENTITY = REGISTRY.register("spawnentity", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("unsuccessful_mod", "spawnentity")));
}