/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.unsuccessful_mod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.unsuccessful_mod.client.renderer.*;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class UnsuccessfulModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(UnsuccessfulModModEntities.SPAWN_NOT_FOUND_BLOCKS.get(), SpawnNotFoundBlocksRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.HEROBRINE.get(), HerobrineRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.ENTITY_NOT_FOUND.get(), EntityNotFoundRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.INVISIBLE_STEP.get(), InvisibleStepRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.COBBLESTONE_SPLINTER.get(), CobblestoneSplinterRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.GLITCH_COW.get(), GlitchCowRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.PIG_HUMAN.get(), PigHumanRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.GLITCH_ZOMBIE.get(), GlitchZombieRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.GLITCH_GIANT_ZOMBIE.get(), GlitchGiantZombieRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.CAVE_PLAYER.get(), CavePlayerRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.BIG_BOY.get(), BigBoyRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.HCTON.get(), HctonRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.START_PLAYER.get(), StartPlayerRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.ENTITY_ENTITY_ENTITY.get(), EntityEntityEntityRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.ENTITY_HE_IS_HERE.get(), EntityHeIsHereRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.WHITE.get(), WhiteRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.STRANGE_PLAYER_1.get(), StrangePlayer1Renderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.PLAYER_1.get(), Player1Renderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.SPAWN_WATER_OR_LAVA.get(), SpawnWaterOrLavaRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.TIME_CHANGE.get(), TimeChangeRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.ENTITY_ENTITY_ENTITY_2.get(), EntityEntityEntity2Renderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.GLITCH_STEVE.get(), GlitchSteveRenderer::new);
		event.registerEntityRenderer(UnsuccessfulModModEntities.ENTITY_SPAWN_KILL_ANIMAL.get(), EntitySpawnKillAnimalRenderer::new);
	}
}