/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.unsuccessful_mod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.unsuccessful_mod.block.TeleportOverworldBlock;
import net.mcreator.unsuccessful_mod.block.NotFoundBlock;
import net.mcreator.unsuccessful_mod.block.DoorTeleportBlock;
import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

public class UnsuccessfulModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, UnsuccessfulModMod.MODID);
	public static final RegistryObject<Block> NOT_FOUND;
	public static final RegistryObject<Block> TELEPORT_OVERWORLD;
	public static final RegistryObject<Block> DOOR_TELEPORT;
	static {
		NOT_FOUND = REGISTRY.register("not_found", NotFoundBlock::new);
		TELEPORT_OVERWORLD = REGISTRY.register("teleport_overworld", TeleportOverworldBlock::new);
		DOOR_TELEPORT = REGISTRY.register("door_teleport", DoorTeleportBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}