/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.unsuccessful_mod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

public class UnsuccessfulModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, UnsuccessfulModMod.MODID);
	public static final RegistryObject<Item> NOT_FOUND;
	public static final RegistryObject<Item> SPAWN_NOT_FOUND_BLOCKS_SPAWN_EGG;
	public static final RegistryObject<Item> HEROBRINE_SPAWN_EGG;
	public static final RegistryObject<Item> ENTITY_NOT_FOUND_SPAWN_EGG;
	public static final RegistryObject<Item> INVISIBLE_STEP_SPAWN_EGG;
	public static final RegistryObject<Item> COBBLESTONE_SPLINTER_SPAWN_EGG;
	public static final RegistryObject<Item> GLITCH_COW_SPAWN_EGG;
	public static final RegistryObject<Item> PIG_HUMAN_SPAWN_EGG;
	public static final RegistryObject<Item> GLITCH_ZOMBIE_SPAWN_EGG;
	public static final RegistryObject<Item> GLITCH_GIANT_ZOMBIE_SPAWN_EGG;
	public static final RegistryObject<Item> CAVE_PLAYER_SPAWN_EGG;
	public static final RegistryObject<Item> BIG_BOY_SPAWN_EGG;
	public static final RegistryObject<Item> HCTON_SPAWN_EGG;
	public static final RegistryObject<Item> START_PLAYER_SPAWN_EGG;
	public static final RegistryObject<Item> ENTITY_ENTITY_ENTITY_SPAWN_EGG;
	public static final RegistryObject<Item> ENTITY_HE_IS_HERE_SPAWN_EGG;
	public static final RegistryObject<Item> WHITE_SPAWN_EGG;
	public static final RegistryObject<Item> STRANGE_PLAYER_1_SPAWN_EGG;
	public static final RegistryObject<Item> PLAYER_1_SPAWN_EGG;
	public static final RegistryObject<Item> SPAWN_WATER_OR_LAVA_SPAWN_EGG;
	public static final RegistryObject<Item> TIME_CHANGE_SPAWN_EGG;
	public static final RegistryObject<Item> ENTITY_ENTITY_ENTITY_2_SPAWN_EGG;
	public static final RegistryObject<Item> TELEPORT_OVERWORLD;
	public static final RegistryObject<Item> DOOR_TELEPORT;
	public static final RegistryObject<Item> GLITCH_STEVE_SPAWN_EGG;
	public static final RegistryObject<Item> ENTITY_SPAWN_KILL_ANIMAL_SPAWN_EGG;
	static {
		NOT_FOUND = block(UnsuccessfulModModBlocks.NOT_FOUND);
		SPAWN_NOT_FOUND_BLOCKS_SPAWN_EGG = REGISTRY.register("spawn_not_found_blocks_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.SPAWN_NOT_FOUND_BLOCKS, -1, -1, new Item.Properties()));
		HEROBRINE_SPAWN_EGG = REGISTRY.register("herobrine_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.HEROBRINE, -1, -1, new Item.Properties()));
		ENTITY_NOT_FOUND_SPAWN_EGG = REGISTRY.register("entity_not_found_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.ENTITY_NOT_FOUND, -1, -1, new Item.Properties()));
		INVISIBLE_STEP_SPAWN_EGG = REGISTRY.register("invisible_step_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.INVISIBLE_STEP, -1, -1, new Item.Properties()));
		COBBLESTONE_SPLINTER_SPAWN_EGG = REGISTRY.register("cobblestone_splinter_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.COBBLESTONE_SPLINTER, -1, -1, new Item.Properties()));
		GLITCH_COW_SPAWN_EGG = REGISTRY.register("glitch_cow_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.GLITCH_COW, -1, -1, new Item.Properties()));
		PIG_HUMAN_SPAWN_EGG = REGISTRY.register("pig_human_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.PIG_HUMAN, -1, -1, new Item.Properties()));
		GLITCH_ZOMBIE_SPAWN_EGG = REGISTRY.register("glitch_zombie_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.GLITCH_ZOMBIE, -1, -1, new Item.Properties()));
		GLITCH_GIANT_ZOMBIE_SPAWN_EGG = REGISTRY.register("glitch_giant_zombie_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.GLITCH_GIANT_ZOMBIE, -1, -1, new Item.Properties()));
		CAVE_PLAYER_SPAWN_EGG = REGISTRY.register("cave_player_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.CAVE_PLAYER, -1, -1, new Item.Properties()));
		BIG_BOY_SPAWN_EGG = REGISTRY.register("big_boy_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.BIG_BOY, -1, -1, new Item.Properties()));
		HCTON_SPAWN_EGG = REGISTRY.register("hcton_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.HCTON, -1, -1, new Item.Properties()));
		START_PLAYER_SPAWN_EGG = REGISTRY.register("start_player_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.START_PLAYER, -1, -1, new Item.Properties()));
		ENTITY_ENTITY_ENTITY_SPAWN_EGG = REGISTRY.register("entity_entity_entity_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.ENTITY_ENTITY_ENTITY, -1, -1, new Item.Properties()));
		ENTITY_HE_IS_HERE_SPAWN_EGG = REGISTRY.register("entity_he_is_here_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.ENTITY_HE_IS_HERE, -1, -1, new Item.Properties()));
		WHITE_SPAWN_EGG = REGISTRY.register("white_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.WHITE, -1, -1, new Item.Properties()));
		STRANGE_PLAYER_1_SPAWN_EGG = REGISTRY.register("strange_player_1_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.STRANGE_PLAYER_1, -1, -1, new Item.Properties()));
		PLAYER_1_SPAWN_EGG = REGISTRY.register("player_1_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.PLAYER_1, -1, -1, new Item.Properties()));
		SPAWN_WATER_OR_LAVA_SPAWN_EGG = REGISTRY.register("spawn_water_or_lava_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.SPAWN_WATER_OR_LAVA, -1, -1, new Item.Properties()));
		TIME_CHANGE_SPAWN_EGG = REGISTRY.register("time_change_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.TIME_CHANGE, -1, -1, new Item.Properties()));
		ENTITY_ENTITY_ENTITY_2_SPAWN_EGG = REGISTRY.register("entity_entity_entity_2_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.ENTITY_ENTITY_ENTITY_2, -1, -1, new Item.Properties()));
		TELEPORT_OVERWORLD = block(UnsuccessfulModModBlocks.TELEPORT_OVERWORLD);
		DOOR_TELEPORT = doubleBlock(UnsuccessfulModModBlocks.DOOR_TELEPORT);
		GLITCH_STEVE_SPAWN_EGG = REGISTRY.register("glitch_steve_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.GLITCH_STEVE, -1, -1, new Item.Properties()));
		ENTITY_SPAWN_KILL_ANIMAL_SPAWN_EGG = REGISTRY.register("entity_spawn_kill_animal_spawn_egg", () -> new ForgeSpawnEggItem(UnsuccessfulModModEntities.ENTITY_SPAWN_KILL_ANIMAL, -1, -1, new Item.Properties()));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
		return doubleBlock(block, new Item.Properties());
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), properties));
	}
}