/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.unsuccessful_mod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.unsuccessful_mod.entity.*;
import net.mcreator.unsuccessful_mod.UnsuccessfulModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class UnsuccessfulModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, UnsuccessfulModMod.MODID);
	public static final RegistryObject<EntityType<SpawnNotFoundBlocksEntity>> SPAWN_NOT_FOUND_BLOCKS = register("spawn_not_found_blocks", EntityType.Builder.<SpawnNotFoundBlocksEntity>of(SpawnNotFoundBlocksEntity::new, MobCategory.CREATURE)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpawnNotFoundBlocksEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<HerobrineEntity>> HEROBRINE = register("herobrine", EntityType.Builder.<HerobrineEntity>of(HerobrineEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(HerobrineEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EntityNotFoundEntity>> ENTITY_NOT_FOUND = register("entity_not_found", EntityType.Builder.<EntityNotFoundEntity>of(EntityNotFoundEntity::new, MobCategory.CREATURE)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EntityNotFoundEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<InvisibleStepEntity>> INVISIBLE_STEP = register("invisible_step",
			EntityType.Builder.<InvisibleStepEntity>of(InvisibleStepEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(InvisibleStepEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<CobblestoneSplinterEntity>> COBBLESTONE_SPLINTER = register("cobblestone_splinter", EntityType.Builder.<CobblestoneSplinterEntity>of(CobblestoneSplinterEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CobblestoneSplinterEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<GlitchCowEntity>> GLITCH_COW = register("glitch_cow",
			EntityType.Builder.<GlitchCowEntity>of(GlitchCowEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(GlitchCowEntity::new)

					.sized(0.9f, 1.4f));
	public static final RegistryObject<EntityType<PigHumanEntity>> PIG_HUMAN = register("pig_human",
			EntityType.Builder.<PigHumanEntity>of(PigHumanEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(PigHumanEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<GlitchZombieEntity>> GLITCH_ZOMBIE = register("glitch_zombie",
			EntityType.Builder.<GlitchZombieEntity>of(GlitchZombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(GlitchZombieEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<GlitchGiantZombieEntity>> GLITCH_GIANT_ZOMBIE = register("glitch_giant_zombie",
			EntityType.Builder.<GlitchGiantZombieEntity>of(GlitchGiantZombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(GlitchGiantZombieEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<CavePlayerEntity>> CAVE_PLAYER = register("cave_player",
			EntityType.Builder.<CavePlayerEntity>of(CavePlayerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CavePlayerEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<BigBoyEntity>> BIG_BOY = register("big_boy",
			EntityType.Builder.<BigBoyEntity>of(BigBoyEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BigBoyEntity::new).fireImmune().sized(6f, 12f));
	public static final RegistryObject<EntityType<HctonEntity>> HCTON = register("hcton",
			EntityType.Builder.<HctonEntity>of(HctonEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(HctonEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<StartPlayerEntity>> START_PLAYER = register("start_player", EntityType.Builder.<StartPlayerEntity>of(StartPlayerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(StartPlayerEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EntityEntityEntityEntity>> ENTITY_ENTITY_ENTITY = register("entity_entity_entity", EntityType.Builder.<EntityEntityEntityEntity>of(EntityEntityEntityEntity::new, MobCategory.CREATURE)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EntityEntityEntityEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EntityHeIsHereEntity>> ENTITY_HE_IS_HERE = register("entity_he_is_here", EntityType.Builder.<EntityHeIsHereEntity>of(EntityHeIsHereEntity::new, MobCategory.CREATURE)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EntityHeIsHereEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<WhiteEntity>> WHITE = register("white",
			EntityType.Builder.<WhiteEntity>of(WhiteEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WhiteEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<StrangePlayer1Entity>> STRANGE_PLAYER_1 = register("strange_player_1", EntityType.Builder.<StrangePlayer1Entity>of(StrangePlayer1Entity::new, MobCategory.CREATURE)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(StrangePlayer1Entity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<Player1Entity>> PLAYER_1 = register("player_1",
			EntityType.Builder.<Player1Entity>of(Player1Entity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Player1Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SpawnWaterOrLavaEntity>> SPAWN_WATER_OR_LAVA = register("spawn_water_or_lava", EntityType.Builder.<SpawnWaterOrLavaEntity>of(SpawnWaterOrLavaEntity::new, MobCategory.CREATURE)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpawnWaterOrLavaEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<TimeChangeEntity>> TIME_CHANGE = register("time_change", EntityType.Builder.<TimeChangeEntity>of(TimeChangeEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(TimeChangeEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EntityEntityEntity2Entity>> ENTITY_ENTITY_ENTITY_2 = register("entity_entity_entity_2", EntityType.Builder.<EntityEntityEntity2Entity>of(EntityEntityEntity2Entity::new, MobCategory.CREATURE)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EntityEntityEntity2Entity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<GlitchSteveEntity>> GLITCH_STEVE = register("glitch_steve",
			EntityType.Builder.<GlitchSteveEntity>of(GlitchSteveEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(GlitchSteveEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EntitySpawnKillAnimalEntity>> ENTITY_SPAWN_KILL_ANIMAL = register("entity_spawn_kill_animal", EntityType.Builder.<EntitySpawnKillAnimalEntity>of(EntitySpawnKillAnimalEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EntitySpawnKillAnimalEntity::new).fireImmune().sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SpawnNotFoundBlocksEntity.init();
			HerobrineEntity.init();
			EntityNotFoundEntity.init();
			InvisibleStepEntity.init();
			CobblestoneSplinterEntity.init();
			GlitchCowEntity.init();
			PigHumanEntity.init();
			GlitchZombieEntity.init();
			GlitchGiantZombieEntity.init();
			CavePlayerEntity.init();
			BigBoyEntity.init();
			HctonEntity.init();
			StartPlayerEntity.init();
			EntityEntityEntityEntity.init();
			EntityHeIsHereEntity.init();
			WhiteEntity.init();
			StrangePlayer1Entity.init();
			Player1Entity.init();
			SpawnWaterOrLavaEntity.init();
			TimeChangeEntity.init();
			EntityEntityEntity2Entity.init();
			GlitchSteveEntity.init();
			EntitySpawnKillAnimalEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SPAWN_NOT_FOUND_BLOCKS.get(), SpawnNotFoundBlocksEntity.createAttributes().build());
		event.put(HEROBRINE.get(), HerobrineEntity.createAttributes().build());
		event.put(ENTITY_NOT_FOUND.get(), EntityNotFoundEntity.createAttributes().build());
		event.put(INVISIBLE_STEP.get(), InvisibleStepEntity.createAttributes().build());
		event.put(COBBLESTONE_SPLINTER.get(), CobblestoneSplinterEntity.createAttributes().build());
		event.put(GLITCH_COW.get(), GlitchCowEntity.createAttributes().build());
		event.put(PIG_HUMAN.get(), PigHumanEntity.createAttributes().build());
		event.put(GLITCH_ZOMBIE.get(), GlitchZombieEntity.createAttributes().build());
		event.put(GLITCH_GIANT_ZOMBIE.get(), GlitchGiantZombieEntity.createAttributes().build());
		event.put(CAVE_PLAYER.get(), CavePlayerEntity.createAttributes().build());
		event.put(BIG_BOY.get(), BigBoyEntity.createAttributes().build());
		event.put(HCTON.get(), HctonEntity.createAttributes().build());
		event.put(START_PLAYER.get(), StartPlayerEntity.createAttributes().build());
		event.put(ENTITY_ENTITY_ENTITY.get(), EntityEntityEntityEntity.createAttributes().build());
		event.put(ENTITY_HE_IS_HERE.get(), EntityHeIsHereEntity.createAttributes().build());
		event.put(WHITE.get(), WhiteEntity.createAttributes().build());
		event.put(STRANGE_PLAYER_1.get(), StrangePlayer1Entity.createAttributes().build());
		event.put(PLAYER_1.get(), Player1Entity.createAttributes().build());
		event.put(SPAWN_WATER_OR_LAVA.get(), SpawnWaterOrLavaEntity.createAttributes().build());
		event.put(TIME_CHANGE.get(), TimeChangeEntity.createAttributes().build());
		event.put(ENTITY_ENTITY_ENTITY_2.get(), EntityEntityEntity2Entity.createAttributes().build());
		event.put(GLITCH_STEVE.get(), GlitchSteveEntity.createAttributes().build());
		event.put(ENTITY_SPAWN_KILL_ANIMAL.get(), EntitySpawnKillAnimalEntity.createAttributes().build());
	}
}